package spasystems;

/**
 *
 * @author Steven Pozo, DCCO-ESPE, DEES Developers
 */
public class SpaSystems {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
