/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.spaSystem.view;

/**
 *
 * @author Steven Pozo,Elkin Pabón,Ercik Moreira,David Ponce DCCO-ESPE, DEES Developers
 */
public class SpaSystem {
    public static void main(String[] args) {
        System.out.println("This is the spaSystem");
          
    }
}